from .kills import KillsChallenge
from .taggroups import TagGroupKillsChallenge
from .badass import BadassKillsChallenge
from .boss import BossKillsChallenge
from .raid import RaidKillsChallenge
from .element import ElementalKillsChallenge
