# Sliding
*Adds sliding to BL2/TPS/AoDK.*  
Pressing crouch while sprinting will make you slide.
If you jump while sliding, you will jump keep the momentum, which generally makes you go further.  
Sliding down slopes will accelerate you, while sliding up slopes will slow you down.

